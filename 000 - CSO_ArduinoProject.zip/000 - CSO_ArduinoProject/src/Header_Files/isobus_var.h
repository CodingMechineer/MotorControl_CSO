#ifndef ISOBUS_VAR_H
#define ISOBUS_VAR_H

#include <SPI.h>
#include <ISOBUS.h>


void printMessage(ISOBUSMessage msg, char buffer[]);

#endif
